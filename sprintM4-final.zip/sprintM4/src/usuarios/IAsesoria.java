package usuarios;

public interface IAsesoria {
	public void analizarUsuario();
}
